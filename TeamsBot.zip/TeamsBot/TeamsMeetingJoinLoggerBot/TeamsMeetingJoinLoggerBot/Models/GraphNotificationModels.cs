﻿using Microsoft.Graph.Models;

namespace TeamsMeetingJoinLoggerBot.Models
{
    public class GraphNotificationModels
    {

    }
    public class ChangeNotificationEnvelope
    {
        public ChangeNotification[]? Value { get; set; }
    }

    public class ChangeNotification
    {
        public ResourceData? ResourceData { get; set; }
    }

    public class ResourceData
    {
        public string? EventType { get; set; }
        public string? MeetingId { get; set; }
        public DateTimeOffset EventDateTime { get; set; }
        public ParticipantDelta[]? ParticipantsDelta { get; set; }
    }
    public class ParticipantDelta
    {
        public string? RemovedState { get; set; }
        public ParticipantInfo Info { get; set; } = null!;
    }
    public class ParticipantInfo
    {
        public IdentitySet Identity { get; set; } = null!;
    }
    public class IdentitySet
    {
        public UserIdentity User { get; set; } = null!;
    }
    public class UserIdentity
    {
        public string? Id { get; set; }
        public string? DisplayName { get; set; }
    }
}