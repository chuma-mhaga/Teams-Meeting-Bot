﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using TeamsMeetingJoinLoggerBot.Services;
using Microsoft.Bot.Builder.Teams;

namespace TeamsMeetingJoinLoggerBot.Bots
{
    public class MeetingBot : TeamsActivityHandler
    {
        private readonly GraphService _graph;
        private readonly IConfiguration _config;

        public MeetingBot(GraphService graph, IConfiguration config)
        {
            _graph = graph;
            _config = config;
        }

        protected override async Task OnConversationUpdateActivityAsync(
        ITurnContext<IConversationUpdateActivity> turnContext,
        CancellationToken cancellationToken)
        {
            var activity = turnContext.Activity;
            await turnContext.SendActivityAsync($"[DEBUG] Conversation Type: {activity.Conversation?.ConversationType}", cancellationToken: cancellationToken);

            // Only act if bot was added
            if (activity.MembersAdded != null)
            {
                foreach (var member in activity.MembersAdded)
                {

                        await turnContext.SendActivityAsync("[DEBUG] Bot was added to a meeting chat", cancellationToken: cancellationToken);

                        try
                        {
                            // Try getting the meeting info
                            var meetingInfo = await TeamsInfo.GetMeetingInfoAsync(turnContext, cancellationToken: cancellationToken);
                            var joinUrlUri = meetingInfo.Details?.JoinUrl;

                            if (joinUrlUri == null)
                            {
                                await turnContext.SendActivityAsync("❌ Couldn’t retrieve Join URL.", cancellationToken: cancellationToken);
                                return;
                            }

                            string joinUrl = joinUrlUri.ToString();
                            var callbackBase = _config["PublicUrl"];

                            await turnContext.SendActivityAsync($"[DEBUG] Join URL: {joinUrl}", cancellationToken: cancellationToken);
                            await turnContext.SendActivityAsync($"[DEBUG] Callback URL: {callbackBase}/api/callevents", cancellationToken: cancellationToken);

                            // Create Graph subscription
                            var subId = await _graph.CreateMeetingSubscriptionAsync(joinUrl, callbackBase);

                            await turnContext.SendActivityAsync(
                                $"✅ Subscription **{subId}** created – now listening for joins.",
                                cancellationToken: cancellationToken);
                        }
                        catch (Exception ex)
                        {
                            await turnContext.SendActivityAsync(
                                $"❌ Exception while creating subscription: {ex.Message}",
                                cancellationToken: cancellationToken);
                        }
                }
            }

            await base.OnConversationUpdateActivityAsync(turnContext, cancellationToken);
        }
    }
}
