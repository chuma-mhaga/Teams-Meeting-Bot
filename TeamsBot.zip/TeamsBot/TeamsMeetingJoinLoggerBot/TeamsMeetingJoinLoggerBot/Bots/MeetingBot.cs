﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Schema.Teams;
using Microsoft.Bot.Builder.Teams;
using Microsoft.Extensions.Configuration;
using System.Threading;
using System.Threading.Tasks;
using TeamsMeetingJoinLoggerBot.Services;
using System;

namespace TeamsMeetingJoinLoggerBot.Bots
{
    public class MeetingBot : TeamsActivityHandler
    {
        private readonly GraphService _graph;
        private readonly IConfiguration _config;

        public MeetingBot(GraphService graph, IConfiguration config)
        {
            _graph = graph;
            _config = config;
        }

        protected override async Task OnConversationUpdateActivityAsync(
            ITurnContext<IConversationUpdateActivity> turnContext,
            CancellationToken cancellationToken)
        {
            var activity = turnContext.Activity;          
            var botId = activity.Recipient?.Id;

            // ✅ Handle join events
            if (activity.MembersAdded != null)
            {
                foreach (var member in activity.MembersAdded)
                {
                    // Skip if the member is the bot itself
                    if (member.Id == botId)
                        continue;

                    try
                    {
                        TeamsChannelAccount user = await TeamsInfo.GetMemberAsync(turnContext, member.Id, cancellationToken);
                        string participantName = user?.Name ?? "Unknown Participant";
                        DateTime joinTime = DateTime.UtcNow;
                        string? meetingId = activity.Conversation?.Id;
                                                
                        // ✅ Log join to SharePoint
                        await _graph.LogJoinToSharePointAsync(participantName, joinTime, meetingId);

                        // Notify chat
                        await turnContext.SendActivityAsync(
                            $"✅ {participantName} joined the meeting at {joinTime.ToLocalTime():HH:mm:ss}.",
                            cancellationToken: cancellationToken);
                    }
                    catch (ErrorResponseException e)
                    {
                        await turnContext.SendActivityAsync($"⚠️ Could not resolve participant {member.Id}. Exception: {e.Message}", cancellationToken: cancellationToken);
                    }
                }
            }

            // ✅ Handle leave events
            if (activity.MembersRemoved != null)
            {
                foreach (var member in activity.MembersRemoved)
                {
                    if (member.Id == botId)
                        continue;

                    try
                    {
                        TeamsChannelAccount user = await TeamsInfo.GetMemberAsync(turnContext, member.Id, cancellationToken);
                        string participantName = user?.Name ?? "Unknown Participant";
                        DateTime leaveTime = DateTime.UtcNow;

                        // Notify chat only (no SharePoint logging)
                        await turnContext.SendActivityAsync(
                            $"👋 {participantName} left the meeting at {leaveTime.ToLocalTime():HH:mm:ss}.",
                            cancellationToken: cancellationToken);
                    }
                    catch (ErrorResponseException e)
                    {
                        // Happens if user already left and we can't look them up
                        await turnContext.SendActivityAsync(
                            $"👋 A participant left the meeting at {DateTime.UtcNow.ToLocalTime():HH:mm:ss}.",
                            cancellationToken: cancellationToken);
                    }
                }
            }

            await base.OnConversationUpdateActivityAsync(turnContext, cancellationToken);
        }
    }
}
