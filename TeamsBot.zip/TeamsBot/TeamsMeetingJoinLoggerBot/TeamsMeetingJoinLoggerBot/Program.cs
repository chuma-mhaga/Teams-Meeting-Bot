﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.BotFramework;
using Microsoft.Bot.Builder.Integration.AspNet.Core;
using Microsoft.Bot.Connector.Authentication;
using Microsoft.Extensions.DependencyInjection;
using TeamsMeetingJoinLoggerBot.Bots;
using TeamsMeetingJoinLoggerBot.Services;

//using TeamsMeetingJoinLoggerBot.Bots

var builder = WebApplication.CreateBuilder(args);

// 1.  BOT CREDENTIALS (read from configuration)
//     └─ They come from appsettings.json / appsettings.Development.json

var appId = builder.Configuration["MicrosoftAppId"];
var appPassword = builder.Configuration["MicrosoftAppPassword"];


// 2.  Bot Framework services
builder.Services.AddSingleton<IBotFrameworkHttpAdapter, AdapterWithErrorHandler>();
builder.Services.AddSingleton<ICredentialProvider, ConfigurationCredentialProvider>();


// Register the bot implementation itself
builder.Services.AddTransient<IBot, MeetingBot>();

// Add services to the container.


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<GraphService>();
builder.Services.AddSingleton<GraphAuthService>();
builder.Services.AddControllers().AddNewtonsoftJson();


var app = builder.Build();
app.UseRouting();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    //app.UseSwagger();
    //app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.MapGet("/", () => "Bot is running ✔️");

app.Run();
