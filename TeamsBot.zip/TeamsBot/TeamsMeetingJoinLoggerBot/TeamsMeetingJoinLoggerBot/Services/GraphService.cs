﻿using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Graph;
using Microsoft.Graph.Models;
using System.Net.Http.Headers;
using Microsoft.Graph.Communications;
using Microsoft.Graph.Communications.OnlineMeetings;
using Microsoft.Graph.Communications.Common.Transport;

namespace TeamsMeetingJoinLoggerBot.Services
{
    public class GraphService
    {
        private readonly GraphServiceClient _graph;
        private readonly IConfiguration _config;

        public GraphService(IConfiguration config)
        {
            _config = config;

            // Standard client-credential auth
            var credential = new ClientSecretCredential(
                config["AzureAd:TenantId"],
                config["AzureAd:ClientId"],
                config["AzureAd:ClientSecret"]);

            _graph = new GraphServiceClient(credential);
        }

        public async Task CreateMeetingSubscriptionAsync(string notificationUrl)
        {
            var subscription = new Subscription
            {
                ChangeType = "created",
                NotificationUrl = notificationUrl,
                Resource = "/communication/onlineMeetings",
                ExpirationDateTime = DateTime.UtcNow.AddMinutes(60),
                ClientState = "secureClientState123"
            };

            try
            {
                var result = await _graph.Subscriptions.PostAsync(subscription);
                Console.WriteLine($"Subscription created with ID: {result.Id}");
            }
            catch (ServiceException ex)
            {
                Console.WriteLine($"Error creating subscription: {ex.Message}");
                throw;
            }
        }

        /// <summary>Create /renew a rosterUpdated subscription for ONE meeting.</summary>
        public async Task<string> CreateMeetingSubscriptionAsync(string joinWebUrl, string callbackBaseUrl)
        {
            if (string.IsNullOrWhiteSpace(joinWebUrl))
                throw new ArgumentException("joinWebUrl is required", nameof(joinWebUrl));

            // Double-encode the joinWebUrl
            var encodedJoinUrl = Uri.EscapeDataString(Uri.EscapeDataString(joinWebUrl));

            var subscription = new Subscription
            {
                ChangeType = "updated",
                NotificationUrl = $"{callbackBaseUrl}/callevents",
                Resource = $"communications/onlineMeetings(joinWebUrl='{encodedJoinUrl}')/meetingCallEvents",
                ExpirationDateTime = DateTime.UtcNow.AddMinutes(60),
                ClientState = "secret123"
            };

            try
            {
                var createdSub = await _graph.Subscriptions.PostAsync(subscription);
                Console.WriteLine($"✅ Subscription created: {createdSub.Id}");
                return createdSub.Id!;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to create subscription: {ex.Message}");
                throw;
            }
        }

        public async Task LogJoinEventAsync(string accessToken, string siteId, string listId, string participantName, DateTimeOffset? joinTime, string? meetingId)
        {
            var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            var requestUrl = $"https://graph.microsoft.com/v1.0/sites/{siteId}/lists/{listId}/items";

            var payload = new
            {
                fields = new
                {
                    ParticipantName = participantName,
                    JoinTime = joinTime?.UtcDateTime.ToString("o"),
                    MeetingId = meetingId
                }
            };

            var json = System.Text.Json.JsonSerializer.Serialize(payload);
            var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            var response = await client.PostAsync(requestUrl, content);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Failed to post to SharePoint: {response.StatusCode} - {error}");
            }
            else
            {
                Console.WriteLine($"Posted to SharePoint: {participantName}");
            }
        }

        public async Task<string> GetAccessTokenAsync()
        {
            var credential = new ClientSecretCredential(
                _config["AzureAd:TenantId"],
                _config["AzureAd:ClientId"],
                _config["AzureAd:ClientSecret"]);

            var token = await credential.GetTokenAsync(
                new Azure.Core.TokenRequestContext(new[] { "https://graph.microsoft.com/.default" }));

            return token.Token;
        }

        public async Task LogJoinToSharePointAsync(string userName, DateTime joinTime, string? meetingId)
        {
            string accessToken = await GetAccessTokenAsync();

            string siteId = _config["SharePoint:SiteId"];
            string listId = _config["SharePoint:ListId"];

            await LogJoinEventAsync(accessToken, siteId, listId, userName, joinTime, meetingId);
        }

        public async Task LogLeaveToSharePointAsync(string userName, DateTime leaveTime, string? meetingId)
        {
            string accessToken = await GetAccessTokenAsync();

            string siteId = _config["SharePoint:SiteId"];
            string listId = _config["SharePoint:ListId"];

            // Assuming SharePoint list has a "LeftTime" column
            var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            var requestUrl = $"https://graph.microsoft.com/v1.0/sites/{siteId}/lists/{listId}/items";

            var payload = new
            {
                fields = new
                {
                    ParticipantName = userName,
                    LeftTime = leaveTime.ToUniversalTime().ToString("o"),
                    MeetingId = meetingId
                }
            };

            var json = System.Text.Json.JsonSerializer.Serialize(payload);
            var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            var response = await client.PostAsync(requestUrl, content);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"❌ Failed to log leave to SharePoint: {response.StatusCode} - {error}");
            }
            else
            {
                Console.WriteLine($"📤 Leave logged to SharePoint: {userName}");
            }
        }

    }
}
