﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using TeamsMeetingJoinLoggerBot.Services;
using Newtonsoft.Json.Linq;

namespace TeamsMeetingJoinLoggerBot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MeetingCreatedController : ControllerBase
    {
        private readonly GraphService _graphService;
        private readonly IConfiguration _config;

        public MeetingCreatedController(GraphService graphService, IConfiguration config)
        {
            _graphService = graphService;
            _config = config;


        }

        // Handles the Get when Graph does the validation handshake
        [HttpGet]
        public IActionResult Get([FromQuery] string validationToken) 
        {
            return Content(validationToken, "text/plain");
        }

        //Handles the Post notifications for new meetings
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] JObject notificationPayload)
        {
            var notifications = notificationPayload["value"];
            if (notifications == null || !notifications.Any())
                return Ok();

            foreach (var notification in notifications)
            {
                var resource = notification["resource"]?.ToString();

                if (!string.IsNullOrEmpty(resource) && resource.Contains("/onlineMeetings"))
                {
                    var meetingId = notification["resourceData"]?["id"]?.ToString();
                    var joinUrl = notification["resourceData"]?["joinWebUrl"]?.ToString();

                    if (!string.IsNullOrEmpty(joinUrl))
                    {
                        var callbackBaseUrl = _config["PublicUrl"];
                        await _graphService.CreateMeetingSubscriptionAsync(joinUrl, callbackBaseUrl);


                    }
                }

            }
            return Ok();
        }
    }
}
