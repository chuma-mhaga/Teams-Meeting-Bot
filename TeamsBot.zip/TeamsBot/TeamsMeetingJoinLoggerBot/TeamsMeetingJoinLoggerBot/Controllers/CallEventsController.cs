﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using TeamsMeetingJoinLoggerBot.Services;
using TeamsMeetingJoinLoggerBot.Models;

namespace TeamsMeetingJoinLoggerBot.Controllers
{
    [Route("callevents")] // Changed from api/[controller] to match your URL
    [ApiController]
    public class CallEventsController : ControllerBase
    {
        private readonly GraphAuthService _authService;
        private readonly GraphService _graphService;

        public CallEventsController(GraphAuthService authService, GraphService graphService)
        {
            _authService = authService;
            _graphService = graphService;
        }

        // Handle both validation (GET/POST) and notifications (POST)
        [HttpGet]
        public IActionResult Get()
        {
            if (Request.Query.ContainsKey("validationToken"))
            {
                var token = Request.Query["validationToken"];
                return Content(token, "text/plain");   // <-- Graph expects 200 + token
            }
            // Optional: simple health ping
            return Ok("CallEvents endpoint is up");
        }

        // Notifications come here (POST) 
        [HttpPost]
        public async Task<IActionResult> Post()
        {
            // IMPORTANT: Handle validation token for POST requests
            if (Request.Query.ContainsKey("validationToken"))
            {
                var graphtoken = Request.Query["validationToken"];
                Console.WriteLine($"Validation request received with token: {graphtoken}");
                return Content(graphtoken, "text/plain");
            }

            using var reader = new StreamReader(Request.Body);
            var json = await reader.ReadToEndAsync();
            Console.WriteLine("Graph notification received:");
            Console.WriteLine(json);

            // Deserialize envelope
            var envelope = JsonSerializer.Deserialize<ChangeNotificationEnvelope>(json);
            if (envelope?.Value == null) return Ok();

            //Get an access token
            var token = await _authService.GetAccessTokenAsync();

            // Process each notifiction
            foreach (var notice in envelope.Value)
            {
                // Only handle rosterUpdated
                if (notice.ResourceData?.EventType != "rosterUpdate") continue;

                var meetingId = notice.ResourceData?.MeetingId;
                var joinTimeUtc = notice.ResourceData?.EventDateTime;

                foreach (var p in notice.ResourceData.ParticipantsDelta)
                {
                    //Skip leave events
                    if (p.RemovedState != null) continue;

                    var name = p.Info.Identity.User.DisplayName;
                    var userId = p.Info.Identity.User.Id;

                    // Log to SharePoint
                    await _graphService.LogJoinEventAsync(
                        token,
                        siteId: "africanideasdev.sharepoint.com,4715976f-4c74-4c23-a958-10b859247599,1a4f662e-35a7-4d27-9291-fcd98adeea30",
                        listId: "64bba895-2b2a-4cd0-b7b1-49bf37524048",
                        participantName: name,
                        joinTime: joinTimeUtc,
                        meetingId: meetingId);

                    Console.WriteLine($"Logged join: {name} @ {joinTimeUtc:0}");
                }
            }

            return Ok();
        }
    }
}